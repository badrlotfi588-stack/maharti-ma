const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");

const app = express();
const db = new Database("maharti.db");
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS services(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT NOT NULL,
  price INTEGER NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS orders(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  service_id INTEGER NOT NULL,
  buyer_id INTEGER NOT NULL,
  seller_id INTEGER NOT NULL,
  status TEXT DEFAULT 'pending',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(service_id) REFERENCES services(id),
  FOREIGN KEY(buyer_id) REFERENCES users(id),
  FOREIGN KEY(seller_id) REFERENCES users(id)
);
`);

app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(session({
  secret: process.env.SESSION_SECRET || "change-this-secret-before-production",
  resave:false,
  saveUninitialized:false,
  cookie:{httpOnly:true, sameSite:"lax", secure:false, maxAge:1000*60*60*24*7}
}));
app.use(express.static(path.join(__dirname,"public")));

function user(req){ return req.session.user || null; }
function requireAuth(req,res,next){
  if(!user(req)) return res.status(401).json({error:"خاصك تسجل الدخول أولا"});
  next();
}

app.get("/api/me",(req,res)=>res.json({user:user(req)}));

app.post("/api/register", async (req,res)=>{
  const {name,email,password}=req.body;
  if(!name || !email || !password || password.length<6)
    return res.status(400).json({error:"دخل الاسم والإيميل وكلمة سر من 6 أحرف على الأقل"});
  try{
    const hash=await bcrypt.hash(password,12);
    const info=db.prepare("INSERT INTO users(name,email,password) VALUES(?,?,?)").run(name.trim(),email.trim().toLowerCase(),hash);
    const u={id:info.lastInsertRowid,name:name.trim(),email:email.trim().toLowerCase()};
    req.session.user=u;
    res.json({user:u});
  }catch(e){
    if(String(e).includes("UNIQUE")) return res.status(409).json({error:"هاد الإيميل مسجل من قبل"});
    res.status(500).json({error:"وقع مشكل فالتسجيل"});
  }
});

app.post("/api/login", async (req,res)=>{
  const {email,password}=req.body;
  const row=db.prepare("SELECT * FROM users WHERE email=?").get((email||"").trim().toLowerCase());
  if(!row || !(await bcrypt.compare(password||"",row.password)))
    return res.status(401).json({error:"الإيميل أو كلمة السر غير صحيحة"});
  req.session.user={id:row.id,name:row.name,email:row.email};
  res.json({user:req.session.user});
});

app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));

app.get("/api/services",(req,res)=>{
  const rows=db.prepare(`
    SELECT s.*, u.name seller
    FROM services s JOIN users u ON u.id=s.user_id
    ORDER BY s.id DESC
  `).all();
  res.json({services:rows});
});

app.get("/api/services/:id",(req,res)=>{
  const row=db.prepare(`
    SELECT s.*,u.name seller,u.email seller_email
    FROM services s JOIN users u ON u.id=s.user_id WHERE s.id=?
  `).get(req.params.id);
  if(!row) return res.status(404).json({error:"الخدمة غير موجودة"});
  res.json({service:row});
});

app.post("/api/services",requireAuth,(req,res)=>{
  const {title,category,description,price}=req.body;
  if(!title||!category||!description||!Number.isFinite(Number(price))||Number(price)<1)
    return res.status(400).json({error:"عمر جميع الخانات بشكل صحيح"});
  const info=db.prepare(
    "INSERT INTO services(user_id,title,category,description,price) VALUES(?,?,?,?,?)"
  ).run(req.session.user.id,title.trim(),category.trim(),description.trim(),Math.round(Number(price)));
  res.json({id:info.lastInsertRowid});
});

app.get("/api/my-services",requireAuth,(req,res)=>{
  res.json({services:db.prepare("SELECT * FROM services WHERE user_id=? ORDER BY id DESC").all(req.session.user.id)});
});

app.post("/api/orders",requireAuth,(req,res)=>{
  const service=db.prepare("SELECT * FROM services WHERE id=?").get(req.body.service_id);
  if(!service) return res.status(404).json({error:"الخدمة غير موجودة"});
  if(service.user_id===req.session.user.id) return res.status(400).json({error:"مايمكنش تطلب خدمتك أنت"});
  const info=db.prepare(
    "INSERT INTO orders(service_id,buyer_id,seller_id) VALUES(?,?,?)"
  ).run(service.id,req.session.user.id,service.user_id);
  res.json({id:info.lastInsertRowid,message:"تم إرسال الطلب للبائع"});
});

app.get("/api/my-orders",requireAuth,(req,res)=>{
  const rows=db.prepare(`
    SELECT o.*,s.title,s.price,
      b.name buyer_name, sl.name seller_name
    FROM orders o
    JOIN services s ON s.id=o.service_id
    JOIN users b ON b.id=o.buyer_id
    JOIN users sl ON sl.id=o.seller_id
    WHERE o.buyer_id=? OR o.seller_id=?
    ORDER BY o.id DESC
  `).all(req.session.user.id,req.session.user.id);
  res.json({orders:rows});
});

app.patch("/api/orders/:id",requireAuth,(req,res)=>{
  const allowed=["pending","accepted","completed","cancelled"];
  if(!allowed.includes(req.body.status)) return res.status(400).json({error:"حالة غير صالحة"});
  const order=db.prepare("SELECT * FROM orders WHERE id=?").get(req.params.id);
  if(!order || (order.buyer_id!==req.session.user.id && order.seller_id!==req.session.user.id))
    return res.status(404).json({error:"الطلب غير موجود"});
  db.prepare("UPDATE orders SET status=? WHERE id=?").run(req.body.status,req.params.id);
  res.json({ok:true});
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));

const PORT=process.env.PORT||3000;
app.listen(PORT,()=>console.log(`Maharti.ma running on http://localhost:${PORT}`));
