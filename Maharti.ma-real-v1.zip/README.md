# Maharti.ma — نسخة حقيقية V1

هذه النسخة فيها Backend + SQLite + تسجيل حسابات + نشر خدمات + طلبات + Dashboard.

## التشغيل على الكمبيوتر
1. ثبت Node.js 20+.
2. افتح Terminal داخل مجلد المشروع.
3. شغل:
   npm install
   npm start
4. افتح:
   http://localhost:3000

## قبل النشر العمومي
- غير SESSION_SECRET إلى قيمة قوية في متغير بيئي.
- فعل HTTPS وsecure cookies.
- استعمل PostgreSQL أو MySQL عند التوسع.
- أضف مزود دفع قانوني ومتاح في بلدك قبل استقبال الأداءات.
- أضف email verification وrate limiting وCSRF protection ونسخ احتياطية لقاعدة البيانات.
