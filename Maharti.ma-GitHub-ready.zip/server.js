const express = require("express");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const crypto = require("crypto");
const path = require("path");

const app = express();
const isProduction = process.env.NODE_ENV === "production";
const dbPath = process.env.DB_PATH || path.join(__dirname, "maharti.db");
const db = new Database(dbPath);
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

// Basic security headers (no extra dependency required).
app.disable("x-powered-by");
app.set("trust proxy", 1);
app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
  if (isProduction) {
    res.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
  }
  next();
});

// Small in-memory rate limiter for auth/API abuse. For multiple servers, use Redis.
const buckets = new Map();
function rateLimit({ windowMs = 60_000, max = 120, key = req => req.ip } = {}) {
  return (req, res, next) => {
    const now = Date.now();
    const k = key(req);
    let b = buckets.get(k);
    if (!b || now - b.start >= windowMs) b = { start: now, count: 0 };
    b.count += 1;
    buckets.set(k, b);
    if (b.count > max) {
      res.setHeader("Retry-After", String(Math.ceil((windowMs - (now - b.start)) / 1000)));
      return res.status(429).json({ error: "طلبات كثيرة بزاف، عاود المحاولة من بعد" });
    }
    next();
  };
}

app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: true, limit: "100kb" }));
app.use(rateLimit({ windowMs: 60_000, max: 180 }));

const sessionSecret = process.env.SESSION_SECRET || (!isProduction ? crypto.randomBytes(32).toString("hex") : null);
if (!sessionSecret) throw new Error("SESSION_SECRET is required in production");

app.use(session({
  secret: sessionSecret,
  resave: false,
  saveUninitialized: false,
  name: "maharti.sid",
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: isProduction,
    maxAge: 1000 * 60 * 60 * 24 * 7
  }
}));

app.use("/api/register", rateLimit({ windowMs: 15 * 60_000, max: 10 }));
app.use("/api/login", rateLimit({ windowMs: 15 * 60_000, max: 15 }));

const publicDir = path.join(__dirname, "public");
app.use(express.static(publicDir, {
  index: "index.html",
  maxAge: isProduction ? "1h" : 0
}));

db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS services(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT NOT NULL,
  price INTEGER NOT NULL,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS orders(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  service_id INTEGER NOT NULL,
  buyer_id INTEGER NOT NULL,
  seller_id INTEGER NOT NULL,
  status TEXT DEFAULT 'pending',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(service_id) REFERENCES services(id) ON DELETE CASCADE,
  FOREIGN KEY(buyer_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(seller_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_services_user_id ON services(user_id);
CREATE INDEX IF NOT EXISTS idx_orders_buyer_id ON orders(buyer_id);
CREATE INDEX IF NOT EXISTS idx_orders_seller_id ON orders(seller_id);
`);

function currentUser(req) { return req.session.user || null; }
function requireAuth(req, res, next) {
  if (!currentUser(req)) return res.status(401).json({ error: "خاصك تسجل الدخول أولا" });
  next();
}
function cleanText(value, max) {
  if (typeof value !== "string") return "";
  return value.trim().replace(/[\u0000-\u001F\u007F]/g, "").slice(0, max);
}
function validId(value) {
  const n = Number(value);
  return Number.isSafeInteger(n) && n > 0 ? n : null;
}
function noStore(res) { res.setHeader("Cache-Control", "no-store"); }

app.get("/health", (req, res) => res.json({ ok: true, service: "maharti" }));
app.get("/api/me", (req, res) => { noStore(res); res.json({ user: currentUser(req) }); });

app.post("/api/register", async (req, res) => {
  noStore(res);
  const name = cleanText(req.body.name, 80);
  const email = cleanText(req.body.email, 254).toLowerCase();
  const password = typeof req.body.password === "string" ? req.body.password : "";
  if (!name || !/^\S+@\S+\.\S+$/.test(email) || password.length < 8 || password.length > 128) {
    return res.status(400).json({ error: "دخل اسم صحيح، إيميل صحيح، وكلمة سر من 8 حتى 128 حرف" });
  }
  try {
    const hash = await bcrypt.hash(password, 12);
    const info = db.prepare("INSERT INTO users(name,email,password) VALUES(?,?,?)").run(name, email, hash);
    const u = { id: info.lastInsertRowid, name, email };
    req.session.regenerate(err => {
      if (err) return res.status(500).json({ error: "وقع مشكل فالجلسة" });
      req.session.user = u;
      res.json({ user: u });
    });
  } catch (e) {
    if (String(e).includes("UNIQUE")) return res.status(409).json({ error: "هاد الإيميل مسجل من قبل" });
    res.status(500).json({ error: "وقع مشكل فالتسجيل" });
  }
});

app.post("/api/login", async (req, res) => {
  noStore(res);
  const email = cleanText(req.body.email, 254).toLowerCase();
  const password = typeof req.body.password === "string" ? req.body.password : "";
  const row = db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if (!row || !(await bcrypt.compare(password, row.password))) {
    return res.status(401).json({ error: "الإيميل أو كلمة السر غير صحيحة" });
  }
  const u = { id: row.id, name: row.name, email: row.email };
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "وقع مشكل فالجلسة" });
    req.session.user = u;
    res.json({ user: u });
  });
});

app.post("/api/logout", (req, res) => {
  noStore(res);
  req.session.destroy(() => {
    res.clearCookie("maharti.sid", { httpOnly: true, sameSite: "lax", secure: isProduction });
    res.json({ ok: true });
  });
});

app.get("/api/services", (req, res) => {
  const rows = db.prepare(`
    SELECT s.id,s.user_id,s.title,s.category,s.description,s.price,s.created_at,u.name seller
    FROM services s JOIN users u ON u.id=s.user_id ORDER BY s.id DESC LIMIT 100
  `).all();
  res.json({ services: rows });
});

app.get("/api/services/:id", (req, res) => {
  const id = validId(req.params.id);
  if (!id) return res.status(400).json({ error: "معرف الخدمة غير صالح" });
  const row = db.prepare(`
    SELECT s.id,s.user_id,s.title,s.category,s.description,s.price,s.created_at,u.name seller
    FROM services s JOIN users u ON u.id=s.user_id WHERE s.id=?
  `).get(id);
  if (!row) return res.status(404).json({ error: "الخدمة غير موجودة" });
  res.json({ service: row });
});

app.post("/api/services", requireAuth, (req, res) => {
  const title = cleanText(req.body.title, 120);
  const category = cleanText(req.body.category, 60);
  const description = cleanText(req.body.description, 2000);
  const price = Number(req.body.price);
  if (!title || !category || !description || !Number.isSafeInteger(price) || price < 1 || price > 1_000_000) {
    return res.status(400).json({ error: "عمر جميع الخانات بشكل صحيح (الثمن بين 1 و1,000,000)" });
  }
  const info = db.prepare("INSERT INTO services(user_id,title,category,description,price) VALUES(?,?,?,?,?)")
    .run(req.session.user.id, title, category, description, price);
  res.json({ id: info.lastInsertRowid });
});

app.get("/api/my-services", requireAuth, (req, res) => {
  res.json({ services: db.prepare("SELECT * FROM services WHERE user_id=? ORDER BY id DESC").all(req.session.user.id) });
});

app.post("/api/orders", requireAuth, (req, res) => {
  const serviceId = validId(req.body.service_id);
  if (!serviceId) return res.status(400).json({ error: "الخدمة غير صالحة" });
  const service = db.prepare("SELECT * FROM services WHERE id=?").get(serviceId);
  if (!service) return res.status(404).json({ error: "الخدمة غير موجودة" });
  if (service.user_id === req.session.user.id) return res.status(400).json({ error: "مايمكنش تطلب خدمتك أنت" });
  const existing = db.prepare("SELECT id FROM orders WHERE service_id=? AND buyer_id=? AND status IN ('pending','accepted')")
    .get(service.id, req.session.user.id);
  if (existing) return res.status(409).json({ error: "عندك طلب مفتوح لهاد الخدمة من قبل" });
  const info = db.prepare("INSERT INTO orders(service_id,buyer_id,seller_id) VALUES(?,?,?)")
    .run(service.id, req.session.user.id, service.user_id);
  res.json({ id: info.lastInsertRowid, message: "تم إرسال الطلب للبائع" });
});

app.get("/api/my-orders", requireAuth, (req, res) => {
  const rows = db.prepare(`
    SELECT o.*,s.title,s.price,b.name buyer_name,sl.name seller_name
    FROM orders o JOIN services s ON s.id=o.service_id
    JOIN users b ON b.id=o.buyer_id JOIN users sl ON sl.id=o.seller_id
    WHERE o.buyer_id=? OR o.seller_id=? ORDER BY o.id DESC LIMIT 200
  `).all(req.session.user.id, req.session.user.id);
  res.json({ orders: rows });
});

app.patch("/api/orders/:id", requireAuth, (req, res) => {
  const id = validId(req.params.id);
  const status = cleanText(req.body.status, 20);
  const allowed = ["pending", "accepted", "completed", "cancelled"];
  if (!id || !allowed.includes(status)) return res.status(400).json({ error: "حالة أو معرف غير صالح" });
  const order = db.prepare("SELECT * FROM orders WHERE id=?").get(id);
  if (!order || (order.buyer_id !== req.session.user.id && order.seller_id !== req.session.user.id)) {
    return res.status(404).json({ error: "الطلب غير موجود" });
  }
  // Only the seller can accept/complete; buyer can cancel a pending/accepted order.
  if ((status === "accepted" || status === "completed") && order.seller_id !== req.session.user.id) {
    return res.status(403).json({ error: "غير مسموح ليك بهاد العملية" });
  }
  if (status === "cancelled" && order.buyer_id !== req.session.user.id && order.seller_id !== req.session.user.id) {
    return res.status(403).json({ error: "غير مسموح ليك بهاد العملية" });
  }
  if (order.status === "completed" || order.status === "cancelled") {
    return res.status(409).json({ error: "هاد الطلب تسالى من قبل" });
  }
  db.prepare("UPDATE orders SET status=? WHERE id=?").run(status, id);
  res.json({ ok: true });
});

app.use("/api", (req, res) => res.status(404).json({ error: "API endpoint غير موجود" }));
app.get("*splat", (req, res) => res.sendFile(path.join(publicDir, "index.html")));

const PORT = Number(process.env.PORT) || 3000;
app.listen(PORT, () => console.log(`Maharti.ma running on port ${PORT}`));
