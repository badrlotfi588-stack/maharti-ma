# Maharti.ma — Secure V1

Marketplace مغربي للخدمات والمهارات.

## تشغيل محلي
```bash
npm install
npm start
```
ثم افتح `http://localhost:3000`.

## متغيرات الإنتاج
- `NODE_ENV=production`
- `SESSION_SECRET` = secret طويل وعشوائي
- `PORT` = يحدده مزود الاستضافة غالبا
- `DB_PATH` = مسار قاعدة SQLite على disk دائم، أو استبدل SQLite بـ PostgreSQL قبل التوسع الحقيقي

## حماية مضافة
- تعطيل `X-Powered-By`
- Security headers وHSTS في HTTPS
- Cookie للجلسة: HttpOnly + SameSite=Lax + Secure في الإنتاج
- منع session fixation عبر `session.regenerate()` عند التسجيل/الدخول
- Rate limiting ضد محاولات login/register والـ API abuse
- حد لحجم body requests
- Validation وتنظيف المدخلات وحدود للأطوال والأسعار والمعرفات
- عدم كشف كلمات السر أو email البائع في API الخدمة العامة
- صلاحيات أفضل لتغيير حالات الطلبات
- منع الطلبات المكررة المفتوحة لنفس الخدمة
- Foreign keys + indexes في SQLite
- Health endpoint: `/health`

## مهم قبل استقبال أموال حقيقية
هذه V1 آمنة كبداية وليست تدقيقا أمنيا كاملا. قبل الإنتاج التجاري أضف:
- PostgreSQL/managed database مع backups
- Redis أو rate limiter مركزي إذا استعملت أكثر من server
- CSRF token إذا أضفت state-changing browser forms/cross-site integrations
- email verification + password reset
- 2FA للحسابات الحساسة
- payment provider موثوق ولا تخزن بيانات البطاقات
- logging/monitoring + alerts
- dependency updates وsecurity audit دوري
- persistent disk إذا بقيت على SQLite
